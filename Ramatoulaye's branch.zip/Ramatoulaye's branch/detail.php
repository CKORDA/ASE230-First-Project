<!DOCTYPE html>
<html>
<head>
    <title>Member Detail</title>
</head>
<body>
    <?php
    // Sample work experience data
    $workExperience = [
        [
            'position' => 'Cashier/bookseller',
            'company' => 'Barners&Noble',
            'start_date' => '2020-01-01', // Start date of employment
            'end_date' => '2020-11-01', // End date of employment
        ],
       
    ];

    // Include the work experience display function
    include('functions.php');

    // Display work experiences
    foreach ($workExperience as $experience) {
        echo generateWorkExperience($experience);
    }
    ?>
</body>
</html>
