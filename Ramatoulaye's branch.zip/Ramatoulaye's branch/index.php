<!DOCTYPE html>
<html>
<head>
    <title>Team Member</title>
</head>
<body>
    <?php
    //  team member data
    $teamMembers = [
        [
            'name' => 'Ramatoulaye',
            'dob' => '2000-11-21', // Date of Birth (YYYY-MM-DD)
        ],
    ];

    // Include the age calculation function
    include('functions.php');

    // Display member cards
    foreach ($teamMembers as $index => $member) {
        echo generateMemberCard($member, $index);
    }
    ?>
</body>
</html>
